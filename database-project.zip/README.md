# SoSA Event & Membership Management System

## Getting started

You can run the project using either the .exe or .dmg files available in the folder `dist`.

Before running the application, you need to set up the database by importing the provided SQL file `sosadatabase.sql` into your PostgreSQL database.

The the required user and password when connecting to the database need to be `postgres` and `mQHiLhyE5@h728CEcD` respectively.
